import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import inquirer from 'inquirer';

// Main directory containing folders with MP4 files
const mainDir = './output';

async function getFolders() {
  const folders = await fs.promises.readdir(mainDir, { withFileTypes: true });
  const validFolders = [];

  // Filter folders that don't have an output.mp4 file
  for (const folder of folders) {
    if (folder.isDirectory()) {
      const folderPath = path.join(mainDir, folder.name);
      const files = await fs.promises.readdir(folderPath);
      if (!files.includes('output.mp4')) {
        validFolders.push(folder.name);
      }
    }
  }

  return validFolders;
}

async function createFileList(folder) {
  const folderPath = path.join(mainDir, folder);
  const files = await fs.promises.readdir(folderPath);

  // Filter and sort MP4 files
  const mp4Files = files
    .filter(file => path.extname(file).toLowerCase() === '.mp4')
    .sort((a, b) => {
      const numA = parseInt(path.basename(a, '.mp4'), 10);
      const numB = parseInt(path.basename(b, '.mp4'), 10);
      return numA - numB;
    });

  // Create filelist.txt content
  const fileListContent = mp4Files.map(file => `file '${path.join(folderPath, file)}'`).join('\n');
  await fs.promises.writeFile('filelist.txt', fileListContent);

  console.log('filelist.txt created successfully.');
}

async function runFFmpeg(folder) {
    const folderPath = path.join(mainDir, folder);
  const ffmpegCommand = `ffmpeg -fflags +genpts -f concat -safe 0 -i filelist.txt -c copy -bsf:v h264_mp4toannexb -vsync vfr ${folderPath}/output.mp4`;
  exec(ffmpegCommand, (err, stdout, stderr) => {
    if (err) {
      console.error('Error executing FFmpeg:', err);
      return;
    }
    console.log('Videos concatenated successfully into output.mp4');
    console.log(stdout);
    console.error(stderr);
  });
}

(async function main() {
  const folders = await getFolders();

  if (folders.length === 0) {
    console.log('No folders found without an output.mp4 file.');
    return;
  }

  const { selectedFolder } = await inquirer.prompt([
    {
      type: 'list',
      name: 'selectedFolder',
      message: 'Select a folder to combine MP4 files:',
      choices: folders,
    }
  ]);

  await createFileList(selectedFolder);
  await runFFmpeg(selectedFolder);
})();
