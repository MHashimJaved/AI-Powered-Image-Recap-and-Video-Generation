import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import os
import sys

def is_gradient_image(image, threshold=30):
    """
    Detect if an image is predominantly a gradient or solid color.
    Returns True if the image is likely a gradient/solid color.
    """
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Calculate standard deviation of pixel values
    std_dev = np.std(gray)
    
    # Calculate the difference between consecutive rows
    row_diff = np.abs(np.diff(gray, axis=0))
    avg_row_diff = np.mean(row_diff)
    
    # Calculate the difference between consecutive columns
    col_diff = np.abs(np.diff(gray, axis=1))
    avg_col_diff = np.mean(col_diff)
    
    # Check if the image has very smooth transitions (gradient-like)
    is_smooth = avg_row_diff < threshold and avg_col_diff < threshold
    
    # Check if the image has very little variation
    is_uniform = std_dev < threshold
    
    return is_smooth or is_uniform

def detect_edges(image):
    """Enhance edge detection for manga panels."""
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Apply adaptive thresholding
    binary = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        11,
        2
    )
    
    # Edge detection using Canny
    edges = cv2.Canny(binary, 50, 150)
    
    # Dilate edges to connect nearby lines
    kernel = np.ones((3,3), np.uint8)
    dilated_edges = cv2.dilate(edges, kernel, iterations=2)
    
    return dilated_edges

def contains_meaningful_content(image, min_height=400, threshold=30):
    """
    Enhanced content detection that accounts for manga characteristics
    and filters out gradients and small images.
    """
    height = image.shape[0]
    
    # Check minimum height requirement
    if height < min_height:
        return False
        
    # Check if it's a gradient image
    if is_gradient_image(image):
        return False
    
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Apply adaptive thresholding
    binary = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        11,
        2
    )
    
    # Find edges
    edges = cv2.Canny(binary, 50, 150)
    
    # Calculate edge density
    edge_density = np.sum(edges > 0) / edges.size
    
    # Check for text using connected components
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(binary)
    
    # Filter small components that might be text
    text_like_components = sum(1 for stat in stats if 10 < stat[4] < 200)
    
    # Return true if either sufficient edge density or potential text is found
    return edge_density > 0.01 or text_like_components > 5

def find_panel_boundaries(binary_image):
    """Find horizontal lines that might separate panels."""
    height, width = binary_image.shape
    
    # Create horizontal projection profile
    horizontal_profile = np.sum(binary_image, axis=1)
    
    # Normalize profile
    horizontal_profile = horizontal_profile / width
    
    # Find local minima (potential panel boundaries)
    boundaries = []
    window_size = 20
    
    for i in range(window_size, len(horizontal_profile) - window_size):
        window = horizontal_profile[i-window_size:i+window_size]
        if horizontal_profile[i] == min(window) and horizontal_profile[i] < 0.1:
            boundaries.append(i)
    
    return boundaries

def split_tall_panel(panel):
    """Split a panel that's taller than 4000px into multiple parts."""
    height, width, _ = panel.shape
    
    if height <= 4000:
        return [panel]
    
    # Calculate number of splits needed (round up)
    num_splits = (height + 3999) // 4000
    
    # Calculate the height of each split
    split_height = height // num_splits
    
    # Add some overlap between splits to avoid cutting content
    overlap = 100
    splits = []
    
    for i in range(num_splits):
        start_y = max(0, i * split_height - overlap)
        end_y = min(height, (i + 1) * split_height + overlap)
        
        # Extract the split
        split = panel[start_y:end_y, :].copy()
        splits.append(split)
    
    return splits

def create_blurred_background(image, target_width=1920, target_height=1080, blur_amount=40):
    """Create a blurred and darkened background from the image itself."""
    # Convert CV2 BGR to RGB
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    # Scale up the image to fill the background
    aspect = image.shape[1] / image.shape[0]
    target_aspect = target_width / target_height
    
    if aspect > target_aspect:
        # Image is wider than target
        bg_height = target_height
        bg_width = int(target_height * aspect)
    else:
        # Image is taller than target
        bg_width = target_width
        bg_height = int(target_width / aspect)
    
    # Resize image to fill background
    background = cv2.resize(image_rgb, (bg_width, bg_height))
    
    # Apply strong blur
    background = cv2.GaussianBlur(background, (blur_amount * 2 + 1, blur_amount * 2 + 1), 0)
    
    # Convert to PIL Image for brightness adjustment
    background = Image.fromarray(background)
    
    # Darken the background by 5%
    enhancer = ImageEnhance.Brightness(background)
    background = enhancer.enhance(0.50)  # 0.95 represents 95% of original brightness
    
    # Crop or pad to target size
    if bg_width > target_width:
        # Crop width
        left = (bg_width - target_width) // 2
        right = left + target_width
        background = background.crop((left, 0, right, bg_height))
    else:
        # Create new image with padding
        new_img = Image.new('RGB', (target_width, bg_height))
        paste_x = (target_width - bg_width) // 2
        new_img.paste(background, (paste_x, 0))
        background = new_img
    
    if bg_height > target_height:
        # Crop height
        top = (bg_height - target_height) // 2
        bottom = top + target_height
        background = background.crop((0, top, target_width, bottom))
    else:
        # Create new image with padding
        new_img = Image.new('RGB', (target_width, target_height))
        paste_y = (target_height - bg_height) // 2
        new_img.paste(background, (0, paste_y))
        background = new_img
    
    return background

def add_drop_shadow(image, offset=(0, 0), shadow_blur=15, shadow_opacity=0.8):
    """Add a white glow effect around the image."""
    # Create an RGBA image for the glow
    shadow = Image.new('RGBA', image.size, (0, 0, 0, 0))
    
    # Create a mask from the original image
    if image.mode == 'RGBA':
        mask = image.split()[3]
    else:
        mask = Image.new('L', image.size, 255)
    
    # Apply blur to the mask for soft glow
    shadow.paste('white', (offset[0], offset[1]), mask)
    shadow = shadow.filter(ImageFilter.GaussianBlur(shadow_blur))
    
    # Adjust glow opacity and make it pure white
    white_glow = Image.new('RGBA', image.size, (255, 255, 255, 255))
    shadow = Image.blend(Image.new('RGBA', image.size, (0, 0, 0, 0)), white_glow, shadow_opacity)
    
    return shadow


def resize_with_aspect_ratio(image, target_width=1920, target_height=1080):
    """Resize image maintaining aspect ratio and add blurred background with drop shadow."""
    # Convert CV2 BGR to PIL RGB
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    pil_image = Image.fromarray(image_rgb)
    
    # Calculate aspect ratios
    target_aspect = target_width / target_height
    image_aspect = image.shape[1] / image.shape[0]
    
    # Calculate new dimensions
    if image_aspect > target_aspect:
        # Image is wider than target
        new_width = target_width
        new_height = int(target_width / image_aspect)
    else:
        # Image is taller than target
        new_height = target_height
        new_width = int(target_height * image_aspect)
    
    # Create blurred background
    background = create_blurred_background(image, target_width, target_height)
    
    # Convert background to RGBA
    background = background.convert('RGBA')
    
    # Resize image with high-quality resampling
    resized_image = pil_image.resize((new_width, new_height), Image.Resampling.LANCZOS)
    resized_image = resized_image.convert('RGBA')
    
    # Calculate position to paste (center)
    paste_x = (target_width - new_width) // 2
    paste_y = (target_height - new_height) // 2
    
    # Create drop shadow
    shadow = add_drop_shadow(resized_image)
    
    # Paste shadow and then image
    background.paste(shadow, (paste_x, paste_y), shadow)
    background.paste(resized_image, (paste_x, paste_y), resized_image)
    
    return background

def split_vertical_images(image_path):
    """Split the image into panels and handle tall panels."""
    # Load the image
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Could not load image: {image_path}")
    
    height, width, _ = image.shape
    
    # Get enhanced edges
    edges = detect_edges(image)
    
    # Find panel boundaries
    boundaries = find_panel_boundaries(edges)
    
    # Add start and end boundaries
    boundaries = [0] + boundaries + [height]
    
    # List to store final image chunks
    final_chunks = []
    
    # Extract and process panels between boundaries
    for i in range(len(boundaries) - 1):
        start_y = boundaries[i]
        end_y = boundaries[i + 1]
        
        # Extract panel with padding
        padding = 5
        start_y = max(0, start_y - padding)
        end_y = min(height, end_y + padding)
        panel = image[start_y:end_y, 0:width].copy()
        
        # Check if panel contains content
        if contains_meaningful_content(panel):
            # Split tall panels into smaller chunks
            panel_chunks = split_tall_panel(panel)
            
            # Add all valid chunks to final list
            for chunk in panel_chunks:
                if contains_meaningful_content(chunk):
                    final_chunks.append(chunk)
    
    return final_chunks

def get_next_panel_number(output_folder):
    """Get the next panel number based on existing files in the output folder."""
    existing_files = os.listdir(output_folder)
    panel_numbers = [
        int(f.split('_')[1].split('.')[0])
        for f in existing_files if f.startswith('panel_') and f.endswith('.jpg')
    ]
    return max(panel_numbers, default=0) + 1

def save_chunks(chunks, output_folder):
    """Save the image chunks with proper quality settings and resizing."""
    next_panel_number = get_next_panel_number(output_folder)
    
    for chunk in chunks:
        # Process and save only valid chunks
        if contains_meaningful_content(chunk):
            # Resize and add blurred background
            processed_image = resize_with_aspect_ratio(chunk)
            
            # Convert RGBA to RGB before saving as JPEG
            if processed_image.mode == 'RGBA':
                # Create a white background
                background = Image.new('RGB', processed_image.size, (255, 255, 255))
                # Paste the image on the background using alpha channel
                background.paste(processed_image, mask=processed_image.split()[3])
                processed_image = background
            
            # Save with high quality
            output_filename = os.path.join(output_folder, f'panel_{next_panel_number}.jpg')
            processed_image.save(output_filename, 'JPEG', quality=95)
            print(output_filename)
            next_panel_number += 1

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python slice.py <input_file> <output_folder>")
        sys.exit(1)

    input_file = sys.argv[1]
    output_folder = sys.argv[2]

    # Check if input file exists
    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' not found.")
        sys.exit(1)

    # Create output folder if it doesn't exist
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    try:
        chunks = split_vertical_images(input_file)
        save_chunks(chunks, output_folder)
    except Exception as e:
        print(f"Error processing image: {str(e)}")
        sys.exit(1)