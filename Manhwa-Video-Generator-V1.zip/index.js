import ask from "./libs/utils/ask.js";
import { v4 } from 'uuid';
import fs from "fs";
import inquirer from "inquirer"; // Import inquirer for selection menu
import config from "./libs/utils/config.js";
import progress from "./libs/utils/progress.js";
import scale from "./libs/utils/scale.js";
import slice from "./libs/images/slice.js";
import azure from "./libs/ai/azure.js";
import fade from "./libs/animations/effects/fade.js";
import addAudioToVideo from "./libs/animations/actions/addAudio.js";
import { exec } from 'child_process';
import ffmpeg from 'fluent-ffmpeg';

// import StreamlabsPolly from "./libs/utils/voice.js";

process.env.dirname = import.meta.dirname;

config(`${process.env.dirname}/config.json`);

let x = {};
let voiceSelection = 1;

async function selectManhwaFromStore() {
    const files = fs.readdirSync('./store');
    let manhwaList = [];
    for (let file of files) {
        const content = JSON.parse(fs.readFileSync(`./store/${file}`, 'utf-8'));
        manhwaList.push({ name: content.name, id: content.id });
    }
    const { selectedManhwa } = await inquirer.prompt([
        {
            type: 'list',
            name: 'selectedManhwa',
            message: 'Select a manhwa:',
            choices: manhwaList.map(m => m.name)
        }
    ]);
    const selected = manhwaList.find(m => m.name === selectedManhwa);
    return selected.id;
}
async function selectVoice() {
    const { voice } = await inquirer.prompt([
        {
            type: 'list',
            name: 'voice',
            message: 'Select a voice:',
            choices: [
                { name: 'Male', value: 1 },
                { name: 'Female', value: 2 },
            ],
        },
    ]);
    voiceSelection = voice;
    console.log(`You selected: ${voiceSelection === 1 ? 'Male' : 'Female'} voice.`);
    return voiceSelection;
}

if (!(await ask("Did you do this manhwa before ?", "agree"))) {
    x.manhwa = await ask("Please enter manhwa name", "string");
    x.id = v4();
    x.synopsis = await ask("Please enter manhwa synopsis", "string");
    x.path = await ask("Please enter manhwa path", "string");
    
    progress(x.id, "create", x.manhwa, x.synopsis, x.path);
    console.log(`You can now use id "${x.id}" to access your manhwa`);
} else {
    x.id = await selectManhwaFromStore(); // Fetch the manhwa ID based on the selected name
    let name = await progress(x.id, "read", "name");
    console.log(`Recaping "${name}"`);
    x.name = name;
    x.synopsis = await progress(x.id, "read", "synopsis");
    x.path = await progress(x.id, "read", "path");
}
await selectVoice();

let summary = null;
let startManhua = `Dont say "start" or "beginning" or "first page" or "first chapter" or "first episode" or "first season"`;
let name = await progress(x.id, "read", "name");
console.log(`Recaping "${name}"`)
x.name = name;
x.synopsis = await progress(x.id, "read", "synopsis");
x.path = await progress(x.id, "read", "path");

// create folder named x.path inside output
if (!fs.existsSync(`./output/${x.path}`))
    fs.mkdirSync(`./output/${x.path}`);

let folders = fs.readdirSync(`./manhwa/${x.path}`);
let recaps = [];
let i = 0;
for (let folder of folders) {
    let files = fs.readdirSync(`./manhwa/${x.path}/${folder}`);
    const outputSliceDir = `./output/${x.path}`;
    if (!fs.existsSync(outputSliceDir + '/sliced')) {
        for (let file of files) {
            i++;
            let runs = await progress(x.id, "read", "run", "completed")
            if (runs.includes(`./manhwa/${x.path}/${folder}/${file}`))
                continue;

            // Initialize images and pics arrays

            let images = [];
            let pics = [];

            // Check if the sliced folder exists

            images = await slice(`./manhwa/${x.path}/${folder}/${file}`, outputSliceDir);
            for (let image of images) {
                await new Promise((resolve) => setTimeout(resolve, 1000)); // Wait for 0.5 seconds
                let p = await scale(image);
                pics.push(p);
            }


            let input = [];
            for (let pic of pics) {
                input.push({
                    type: "image_url",
                    imageUrl: {
                        url: pic
                    }
                });
            }
            try {
                let pageType = (i == 1) ? "start" : (i == files.length) ? "chapter end" : "normal";
                let message = [
                    {
                        "role": "system",
                        "content": `You are a script writer, you make recap for manhua meant as a youtube video, you must always write it in a story telling vibe with some humorous elements, simple human like narative english and from time to time drop some slangs, ${startManhua} I don't want you to invent new things but just summarize what is happening in the pages provided, make sure each image given to you has a recap even if its random space and the recaps are linked since all those images are slices of one big one, they are sent that way to make animating them easier, I just want the story. I will give you an image and if its first page then you must say what it's in it if not then I will give you summary of past pages, and description of the past characters, you will also get a page number and a page type the type will be either start (markes the first page), normal (marks normal middle pages), finish (marks the last page).\nYou must always respond with the following json:\n{\n"type": "the type of the page like talking or fighting or anything in 2 to 4 words",\n"summary": "add this page to the past summary or create new one if past is null",\n"recap": [\n"the recap which will be read to the user, note it will be read while showing the page sent to you, in case you get multiple images you must make each image alone and in the order that was given to you at first, always create recap for each image, never return unequal array, recap array must equal to image array",\n"recap for the second image you get you must add each image into its own panel"\n],\n"characters": [\n{\n"id": "a unique id that you give to this character which will identify him even if he changes everything about him in some page, for example the whole body of the character changes and it was shown in some page you must keep his id and change his features",\n"name": "character name or a description if its unknown",\n"face": "description for his face, clothes, eyes and hair color, special features, anything that will help you tell the character when you see him in another request without the initial image.",\n"role": "role in the manhua"\n}\n]\n}\nEACH PICTURE MUST HAVE ITS OWN VALUE IN RECAP ARRAY EVEN IF THE TEXT IS CONTINUED IT MUST BE SET ON ITS OWN SEPARATE VALUE THAT WAY IT CAN BE SHOWN IN THE VIDEO VIA THE AUTOMATED SOFTWARE, NEVER RETURN UN-EQUAL RECAP TO IMAGE OR PICTURE, GENERATE RECAME FOR EACH PICTURE\nPlease only respond with new characters don't repeat the same character unless you want to change something in him,\nRespond with the given format only dont change any key and always give valid json and dont use markdown or \`\`\`\nNote there are no breaks on the video between the pages so your recap must be simultanious as if you didnt stop or its not a different message, the reason we are splitting them is for editing part\nALWAYS TREAT THE PAGES EXCEPT THE LAST ONE AS IF THEY ARE CONTINUATION NEVER SAY STUFF LIKE STAY TUNED OR SEE YOU NEXT TIME OR WE ARE BACK OR LETS CONTINUE OR ANYTHING THAT INDICATES A BREAK BETWEEN THE PAGES`
                    },
                    {
                        "role": "user",
                        "content": [
                            {
                                type: "text",
                                test: JSON.stringify({
                                    page_type: pageType,
                                    page_number: i,
                                    summary: summary
                                })
                            },
                            ...input
                        ]
                    }
                ]
                let azureClient = await azure('gpt', message, 'gpt-4o', '2024-02-15-preview', { maxTokens: 4096, temperature: 0.7, topP: 0.95, responseFormat: { type: 'json_object' } });
                azureClient = JSON.parse(azureClient.replace(/['`]/g, ""));
                azureClient.image = images;
                recaps.push(azureClient);
                if (summary == null)
                    summary = azureClient.summary;
                else
                    summary = `${summary} ${azureClient.summary}`;
                startManhua = `Dont say "start" or "beginning" or "first page" or "first chapter" or "first episode" or "first season" or we start with or we kick off with or any other way to say start`;
            } catch (error) {
                console.log(error.message)
            }
        }
    } else {
        console.log(`Sliced folder exists, skipping slicing..`);
    }
}

// Check if recaps.json already exists
const recapsFilePath = `./output/${x.path}/recaps.json`;
if (!fs.existsSync(recapsFilePath)) {
    fs.writeFileSync(recapsFilePath, JSON.stringify(recaps, null, 2));
} else {
    console.log(`Recaps already generated for ${x.path}, skipping...`);
}

while (true)
    if (await ask(`Did you finish proofreading ./output/${x.path}/recaps.json file ?`, "agree"))
        break;

recaps = fs.readFileSync(recapsFilePath);
recaps = JSON.parse(recaps);
config(`${process.env.dirname}/config.json`, { azure_endpoint: 1, azure_key: 1 });
for (let i = 0; i < recaps.length; i++) {
    let recap = recaps[i];
    let panels = [];
    let continuex = false;
    for (let j = 0; j < recap.recap.length; j++) {
        let recp = recap.recap
        if (!recp[j].trim()) {
            console.log(`Skipping empty recap entry at index ${j}`);
            continue; // Skip to the next iteration if the current entry is empty
        }
        let input = {
            voice: `echo`,
            text: recp[j],
            savePath: `./output/${x.path}`,
            customFileName: `${i}-${j}.wav`
        }

        // Check if the corresponding MP4 file already exists
        const mp4FilePath = `./output/${x.path}/${i}.mp4`;
        if (!fs.existsSync(mp4FilePath)) {

            const execPromise = (command) =>
                new Promise((resolve, reject) => {
                    exec(command, (error, stdout, stderr) => {
                        if (error) {
                            reject(error);
                        } else {
                            resolve({ stdout, stderr });
                        }
                    });
                });
            
            // Helper to convert MP3 to WAV
            const convertMp3ToWav = (mp3Path, wavPath) => {
                return new Promise((resolve, reject) => {
                    ffmpeg(mp3Path)
                        .toFormat('wav')
                        .on('end', () => {
                            console.log(`WAV file created: ${wavPath}`);
                            resolve(); // Resolve the promise
                        })
                        .on('error', (err) => {
                            console.error(`Error during MP3 to WAV conversion: ${err.message}`);
                            reject(err); // Reject the promise on error
                        })
                        .save(wavPath);
                });
            };
            

            // await azure('voice', input, 'tts-hd', '2024-08-01-preview');
            // panels.push({
            //     audio: `./output/${x.path}/${i}-${j}.wav`
            // });
            // const polly = new StreamlabsPolly();
            // console.log(input);
            // process.exit();
            // await polly.run(input.text, `./output/${x.path}/${i}-${j}.wav`, false)
            //     .then(() => console.log("Audio file created successfully!"))
            //     .catch((err) => console.error("Error:", err.message));
            // male en-US-AndrewMultilingualNeural
            // female en-US-JennyNeural
            let voiceSelectionString = 'en-US-AndrewMultilingualNeural';
            if (voiceSelection == 2){
                // male voice
                voiceSelectionString = "en-US-JennyNeural"
            }
            console.log(voiceSelectionString);
            console.log(voiceSelection);

             try {
                    var mp3Path = `./output/${x.path}/${i}-${j}.mp3`;
                    var wavPath = `./output/${x.path}/${i}-${j}.wav`;
                    const mp4FilePath = `./output/${x.path}/${i}.mp4`;
                // Generate MP3 using edge-tts
                console.log(`Generating MP3 for ${i}-${j}...`);
                await execPromise(`edge-tts --voice ${voiceSelectionString} --text "${input.text}" --write-media ${mp3Path}`);
                // console.log(`MP3 file generated: ${mp3Path}`);

                // // Convert MP3 to WAV
                // console.log(`Converting MP3 to WAV for ${i}-${j}...`);
                await convertMp3ToWav(mp3Path, wavPath);
                // console.log(`WAV file created: ${wavPath}`);

                // Delete MP3 after conversion
                // console.log(`Deleting MP3 file: ${mp3Path}`);
                try {
                    // await fs.unlink(mp3Path).catch((err) => {
                    //     console.error(`Error deleting MP3 file ${mp3Path}:`, err.message);
                    // });
                    fs.unlinkSync(mp3Path);

                } catch (error){
                    console.error(`Unable to Delete`, error.message);
                }

                // Add to panels
                panels.push({ audio: wavPath });
            } catch (error) {
                console.error(`Error processing audio for ${i}-${j}:`, error.message);
            }

        } else {
            console.log(`MP4 file ${mp4FilePath} already exists, skipping WAV generation...`);
            continuex = true;
        }
    }
    // add images to panels
    if (continuex == false){
        for (let j = 0; j < recap.image.length; j++) {
            if (panels[j] == undefined)
                panels[j] = {};
            panels[j].img = recap.image[j];
        }
        // console.log("Panel Output Fade Images", panels);
        let audio = await fade(panels, `./output/${x.path}/${i}-muted.mp4`, `./black.png`);
        for (let j = 0; j < recap.recap.length; j++)
            fs.unlinkSync(`./output/${x.path}/${i}-${j}.wav`);
        await addAudioToVideo(`./output/${x.path}/${i}-muted.mp4`, audio, `./output/${x.path}/${i}.mp4`)
        fs.unlinkSync(audio);
        fs.unlinkSync(`./output/${x.path}/${i}-muted.mp4`);
        
    } 
}

